from localization import detect_and_extract_descriptors, match_descriptors
from localization.utils import list_image_files, parse_command_line_arguments, AppSettings


def main(appsettings_path: str) -> None:
    settings = AppSettings.from_json(appsettings_path)

    if settings.debug:
        args = settings.default_args
    else:
        args = parse_command_line_arguments()

    frame_descriptors = detect_and_extract_descriptors(
        filepaths=list_image_files(args.frames_dir),
        descriptor=args.descriptor,
        max_keypoints=args.max_keypoints,
        device=args.device,
        verbose=args.verbose
        )
    
    # TODO: One-by-one

    prompt_descriptors = detect_and_extract_descriptors(
        filepaths=list_image_files(args.prompt_dir),
        descriptor=args.descriptor,
        max_keypoints=args.max_keypoints,
        device=args.device,
        verbose=args.verbose
        )

    matches = match_descriptors(
        descriptor=args.descriptor,
        frame_descriptors=frame_descriptors, 
        prompt_descriptors=prompt_descriptors,
        verbose=args.verbose
        )

    for m in matches:
        print(m)

    # TODO


if __name__ == '__main__':
    main('appsettings.json')

