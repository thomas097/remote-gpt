import os
import json
import glob
import argparse
from typing import Any


class AppSettings:
    """
    A class to manage application settings from a JSON file.
    """
    def __init__(self, **data) -> None:
        self._data = data

    @classmethod
    def from_json(cls, filepath: str, encoding: str = 'utf-8') -> 'AppSettings':
        """
        Load settings from a JSON file and return an instance of AppSettings.

        Args:
            filepath (str): The path to the JSON file containing the settings.
            encoding (str, optional): The file encoding. Defaults to 'utf-8'.

        Returns:
            AppSettings: An instance of AppSettings with the loaded data.
        """
        with open(filepath, 'r', encoding=encoding) as file:
            return cls(**json.load(file))

    def __getattr__(self, key: str) -> Any:
        """
        Retrieve a setting by key.

        Args:
            key (str): The key for the desired setting.

        Returns:
            Any: The value associated with the key, or an AppSettings instance if the value is a dictionary.

        Raises:
            Exception: If the key is not found in the settings data.
        """
        value = self._data.get(key, None)
        if value is None:
            raise Exception(f"key '{key}' not found.")
        
        if isinstance(value, dict):
            value = AppSettings(**value)

        return value


def parse_command_line_arguments() -> argparse.Namespace:
    """
    Parse command line arguments for the application.

    Returns:
        Namespace: Parsed command line arguments.
    """
    parser = argparse.ArgumentParser(description="Command line application to perform object localization on image frames.")
    parser.add_argument("--frames_dir", required=True, type=str, 
                        help="Path to directory containing image frames in JPG or PNG format.")
    parser.add_argument("--prompt_dir", required=True, type=str, 
                        help="Path to directory containing images of the item/location of interest.")
    parser.add_argument("--descriptor", required=False, type=str, default="superpoint", choices=['superpoint', 'disk', 'sift'], 
                        help="Type of keypoint descriptor used.")
    parser.add_argument("--max_keypoints", required=False, type=int, default=2048, 
                        help="Maximum number of keypoints to extract.")
    parser.add_argument("--device", required=False, type=str, default="cpu", choices=['cpu', 'cuda'], 
                        help="Device on which to perform computation.")
    parser.add_argument("--verbose", required=False, type=bool, default=True, 
                        help="Whether to write/output progress reports to stdout.")
    return parser.parse_args()


def list_image_files(directory: str, formats: list[str] = ['png', 'jpg']) -> list[str]:
    """
    Generate a sorted list of image file paths in the specified directory.

    Args:
        directory (str): The directory to search for image files.
        formats (list[str], optional): List of file formats to search for. Defaults to ['png', 'jpg'].

    Returns:
        list[str]: Sorted list of image file paths.
    """
    filepaths = []
    for fmt in formats:
        filepaths += glob.glob(os.path.join(directory, f'*.{fmt}'))
    return sorted(filepaths)