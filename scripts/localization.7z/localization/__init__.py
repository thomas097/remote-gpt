import torch
torch.set_grad_enabled(False)

from tqdm import tqdm
from pathlib import Path
from rich.console import Console
from localization.lightglue.utils import load_image, Extractor
from localization.lightglue import LightGlue, SuperPoint, DISK, SIFT
from localization.dtypes import DescriptorResult, MatchResult


CONSOLE = Console()

def create_extractor(name: str, max_keypoints: int, device: str) -> Extractor:
    EXTRACTORS = {
        'superpoint': SuperPoint,
        'disk': DISK,
        'sift': SIFT
    }
    extractor = EXTRACTORS.get(name, None)
    if extractor is None:
        raise Exception(f"Extractor for descriptor '{name}' not found.")
    
    return extractor(max_num_keypoints=max_keypoints).eval().to(device)


def detect_and_extract_descriptors(
        filepaths: list[Path], 
        descriptor: str,
        max_keypoints: int = 2048, 
        device: str = 'cpu',
        verbose: bool = True
        ) -> list[DescriptorResult]:
    """Uses SuperPoint (DeTone et al., 2018) to efficiently detect and extract feature descriptors.

    Args:
        filepaths (list[Path]):        List of image filepaths.
        descriptor (str):              Which descriptor to use. Supported are 'superpoint', 'disk' and 'sift'.
        max_keypoints (int, optional): Maximum number of descriptors to extract from frames (default: 2048).
        device (str, Optional):        Device on which to perform computation: 'cpu' or 'cuda' (default: 'cpu').
        verbose (bool, optional):      Whether to display a progerss bar (default: True).

    Returns:
        list[DescriptorResult]: Keypoint descriptors for each frame.
    """
    extractor = create_extractor(descriptor, max_keypoints=max_keypoints, device=device)

    result = []
    with tqdm(total=len(filepaths), disable=not verbose, desc="Extracting descriptors") as pbar:
        for filepath in filepaths:
            # Load image
            image = load_image(path=filepath)

            # Extract SuperPoint descriptor
            result.append(
                DescriptorResult(
                    filepath=filepath,
                    descriptors=extractor.extract(image),
                    device=device
                )
            )
            pbar.update()

    return result


def match_descriptors(descriptor: str, frame_descriptors: list[DescriptorResult], prompt_descriptors: list[DescriptorResult], verbose: bool = True) -> list[MatchResult]:
    # Init Matching object on same device as point descriptors!
    matcher = LightGlue(features=descriptor).eval()
    matcher.to(frame_descriptors[0].device)

    with tqdm(total=len(frame_descriptors), disable=not verbose, desc="Matching descriptors") as pbar:

        match_results = []
        for frame_descr in frame_descriptors:

            # Accumulate scores across LODs of prompt
            # (if multiple LODs are provided)
            match_score = 0

            for prompt_descr in prompt_descriptors:

                # Match descriptors of frame and prompt images
                matches01 = matcher({"image0": prompt_descr.descriptors, "image1": frame_descr.descriptors})

                # Measure match as sum of pairwise confidence scores
                match_score += torch.sum(matches01['scores'][0])

                # Keypoints detected in prompt and target frame
                prompt_keypoint_ids = matches01['matches'][0][:, 0]
                prompt_keypoints = prompt_descr.descriptors['keypoints'][0][prompt_keypoint_ids]

                frame_keypoint_ids = matches01['matches'][0][:, 1]
                frame_keypoints = frame_descr.descriptors['keypoints'][0][frame_keypoint_ids]

            match_results.append(
                MatchResult(
                    filepath=frame_descr.filepath,
                    frame_keypoints=frame_keypoints,
                    prompt_keypoints=prompt_keypoints,
                    score=match_score
                )
            )
            pbar.update()

    return match_results