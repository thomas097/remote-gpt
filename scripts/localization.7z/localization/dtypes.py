import torch
from dataclasses import dataclass

@dataclass
class DescriptorResult:
    filepath: str
    descriptors: dict
    device: str

@dataclass
class MatchResult:
    filepath: str
    prompt_keypoints: torch.Tensor
    frame_keypoints: torch.Tensor
    score: float

    def __str__(self) -> str:
        return f"MatchResult(filepath='{self.filepath}', prompt_keypoints=[[...]], frame_keypoints=[[...]], score={self.score})"
    